//
//  ConsoleLogMessageHandler.h
//  JsBridgeHandler
//
//  Created by admin on 2019/5/24.
//  Copyright © 2019 admin. All rights reserved.
//
#import <WebKit/WebKit.h>
#ifndef ConsoleLogMessageHandler_h
#define ConsoleLogMessageHandler_h
@interface ConsoleLogMessageHandler: NSObject<WKScriptMessageHandler>

@end
#endif /* MyScriptMessageHandler_h */
