//
//  SXBaseInfo.h
//  AFNetworking
//
//  Created by yanluojun on 2019/8/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SXBaseInfo : NSObject

@end

NS_ASSUME_NONNULL_END
