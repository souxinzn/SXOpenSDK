//
//  JsLoadCompleteListener.h
//  SXIotSDK
//
//  Created by ShimLin on 2019/8/9.
//

#import <Foundation/Foundation.h>
#import "OnJsLoadComplete.h"

NS_ASSUME_NONNULL_BEGIN

@interface OnJsLoadCompleteImpl : NSObject<OnJsLoadComplete>

@end

NS_ASSUME_NONNULL_END
