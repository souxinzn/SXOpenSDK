//
//  RelayDevHelper.h
//  SXIotSDK
//
//  Created by admin on 2019/8/16.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RelayDevHelper : NSObject

+ (void)query:(NSString*)zkId;

@end

NS_ASSUME_NONNULL_END
