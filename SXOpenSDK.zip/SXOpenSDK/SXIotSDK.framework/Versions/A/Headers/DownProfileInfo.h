//
//  DownProfileInfo.h
//  SXIotSDK
//
//  Created by ShimLin on 2019/9/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DownProfileInfo : NSObject

@end

NS_ASSUME_NONNULL_END
