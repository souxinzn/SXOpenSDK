//
//  Constant.h
//  SXIoTSDK
//
//  Created by ShimLin on 2019/5/28.
//  Copyright © 2019 ShimLin. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, ClientResult)
{
    XMGTypeTop,
    XMGTypeBottom,
};

NS_ASSUME_NONNULL_BEGIN

@interface Constant : NSObject

@end

NS_ASSUME_NONNULL_END
