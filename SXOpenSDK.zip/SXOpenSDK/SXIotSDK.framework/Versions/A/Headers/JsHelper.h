//
//  JsHelper.h
//  SXIoTSDK
//
//  Created by ShimLin on 2019/5/28.
//  Copyright © 2019 ShimLin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JsBridgeHandler.h"

NS_ASSUME_NONNULL_BEGIN

@interface JsHelper : NSObject

+ (void) loadJs;

@end

NS_ASSUME_NONNULL_END
