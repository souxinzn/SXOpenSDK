//
//  OnUdpDataListener.h
//  SXUDPSDK_Example
//
//  Created by ShimLin on 2019/7/12.
//  Copyright © 2019 ShimLin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UdpClientInterface.h"

NS_ASSUME_NONNULL_BEGIN

@interface OnUdpDataListener : NSObject<UdpClientInterface>

@end

NS_ASSUME_NONNULL_END
