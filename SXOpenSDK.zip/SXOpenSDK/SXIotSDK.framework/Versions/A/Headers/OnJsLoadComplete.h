//
//  OnJsLoadComplete.h
//  SXIotSDK
//
//  Created by ShimLin on 2019/8/9.
//

#ifndef OnJsLoadComplete_h
#define OnJsLoadComplete_h

@protocol OnJsLoadComplete <NSObject>

- (void)success;

@end

#endif /* OnJsLoadComplete_h */
