//
//  UdpCustState.h
//  SXUDPSDK
//
//  Created by ShimLin on 2019/7/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

static BOOL custState_netOK = YES ;
static BOOL custState_netIsWifi = YES ;

@interface UdpCustState : NSObject

@end

NS_ASSUME_NONNULL_END
