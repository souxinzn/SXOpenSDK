//
//  UdpCustTaskInterface.h
//  Pods
//
//  Created by ShimLin on 2019/7/12.
//

#ifndef UdpCustTaskInterface_h
#define UdpCustTaskInterface_h

@protocol UdpCustTaskInterface <NSObject>

- (void) task_callBack;

@end

#endif /* UdpCustTaskInterface_h */
