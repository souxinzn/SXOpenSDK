//
//  UdpCustParam.h
//  CocoaAsyncSocket
//
//  Created by ShimLin on 2019/7/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

static NSString *custParam_custIp = @"192.168.0.1" ;
static NSString *custParam_localPath = @"" ;
static NSString *custParam_appVersion = @"1.0.1" ;
static NSString *custParam_sysVersion = @"1.0.1" ;

@interface UdpCustParam : NSObject


@end

NS_ASSUME_NONNULL_END
