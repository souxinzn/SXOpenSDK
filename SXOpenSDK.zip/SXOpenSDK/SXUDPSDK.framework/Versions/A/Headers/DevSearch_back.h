//
//  DevSearch_back.h
//  CocoaAsyncSocket
//
//  Created by ShimLin on 2019/7/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DevSearch_back : NSObject

@property (nonatomic, copy) NSString* did;
@property (nonatomic, copy) NSString* d_ip;
@property (nonatomic, assign) int d_port;
@property (nonatomic, copy) NSString* backTime14;

@end

NS_ASSUME_NONNULL_END
